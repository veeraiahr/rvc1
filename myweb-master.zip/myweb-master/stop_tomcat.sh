#! /bin/bash
/opt/tomcat9/bin/shutdown.sh
