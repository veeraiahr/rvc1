#! /bin/bash
/opt/tomcat9/bin/startup.sh


